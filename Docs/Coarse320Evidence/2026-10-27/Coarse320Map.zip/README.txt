320 M BAKED COARSE MAP - learned-lowfreq-overview-v1

937 columns x 469 rows, covering 299520 x 149760 world meters.
Node spacing: 320 meters. Height values: meters, sea level = 0.
Origin: X=-149760, Z=-74880. Maximum: X=149760, Z=74880.
Bake ID: 653a72959be6e6ec9abb8e9643c685b2c690c183768a109f2110ede02b7dfb99

Coarse320.bytes: AVWF0001 height, source biome and land-mask atlas.
Coarse320.climate.bytes: AVCL0001 climate paired to the exact height SHA256.
Coarse320-height.tif: float32 elevation. Local X/Z meters; no geographic CRS.
TIFF row zero is maximum Z; AVWF row zero is minimum Z.
identity.json / result.json: source identities, hashes, size and bake timings.
evaluation.json / consumer.json: actual-data and project C# reader checks.

This is learned intermediate elevation from the pinned InfiniteDiffusion
coarse/base stages, filtered to 320m. The fine residual decoder is omitted.
It is not an upscaled copy of the old 1280m map. Climate retains 1280m source
fidelity; temperature follows the new elevation using the original lapse rate.
The GPU/batch-derived identity differs from the current playable CPU world.

These files are standalone source data. Reading them requires no model,
GPU inference or LOD bake. They do not replace your current project assets.
Import/in-game integration, fine-patch blending and performance acceptance
are separate work. Do not rename this as the existing CPU world identity.
